package ch14;

public class Student {
	
	String studentname;
	int money;
	
	public Student(String name, int money) {
		this.studentname = name;
		this.money = money;
	}
	
	public void takeBus(Bus bus) {
		bus.take(1000);
		this.money -= 1000;
	}
	
	 
	 	 
	 public void showInfo() {
		 System.out.println(studentname + "���� ���� ���� " + money + " �� �Դϴ�.");
	 }
	
}
