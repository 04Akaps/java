package ch14;

public class Bus {
	int busNumber;
	int passengerCount;
	int money;
	
	public Bus(int Number) {
		this.busNumber = Number;
	}
	
	public void take(int money) {
		this.money +=money;
		passengerCount++;
	}
	
}
