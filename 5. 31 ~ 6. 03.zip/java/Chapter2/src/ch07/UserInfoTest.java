package ch07;

public class UserInfoTest {

	public static void main(String[] args) {
		
		UserInfo Hojin = new UserInfo("b12345", "abc", "hojin");
		System.out.println(Hojin.showUserInfo());
	}

}
