package ch22;

public class TwoDimensionTest {

	public static void main(String[] args) {
		
		int [][] arr = {{1,2,3}, {1,2,3,4}};
		
		int i,j;	//for ���� ���� ���� ����
		
		for(i=0; i<arr.length; i++) {	//arr.length = 2
			for(j=0; j<arr[i].length; j++) {	//arr[i].length = 3 or 4
				System.out.print(arr[i][j] +", ");
			}
			System.out.println("\t" + arr[i].length);
		}
	}
}
