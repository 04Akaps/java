package ch09;

public class Student_Test {

	public static void main(String[] args) {
		
		Student Hojin = new Student(100, "sdl155");
		Hojin.setKoreaSubject("����",100);
		Hojin.setMathSubject("����", 80);
		
		Hojin.Test();
		
		
	}

}
