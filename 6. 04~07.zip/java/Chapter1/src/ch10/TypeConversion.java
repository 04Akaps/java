package ch10;

public class TypeConversion {

	public static void main(String[] args) {
		
		int iNum = 255;
		byte bNum = (byte)iNum;
		
		System.out.println(bNum);
	}

}
