package ch12;

public class Hojin {

	public static void main(String[] args) {
		
		Person Hojin = new Person();
		
		
		System.out.println(Hojin.age);
		System.out.println(Hojin.name);
	}

}
