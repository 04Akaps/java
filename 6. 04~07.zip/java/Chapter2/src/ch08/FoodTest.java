package ch08;

public class FoodTest {

	public static void main(String[] args) {
		
		Food A = new Food();
		
		A.number = 202011020003l;
		A.phoneNumber = 01023450001;
		A.address = "����� ������ ���ﵿ";
		A.day = 20201102;
		A.time = 130258;
		A.price = 35000;
		A.callNumber = "0003";
		
		A.FoodInfo();
	}

}
