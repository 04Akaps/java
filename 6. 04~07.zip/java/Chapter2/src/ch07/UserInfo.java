package ch07;

public class UserInfo {
	
	public String userId;
	public String userPassWord;
	public String userName;
	public String userAddress;
	public String userNumber;
	
	public UserInfo() {}
	
	public UserInfo(String userId, String userPasWord, String userName) {
		this.userId = userId;
		this.userPassWord = userPassWord;
		this.userName = userName;
	}
	
	public String showUserInfo() {
		return "�������� ���̵�� " +userId + "�̰�, ��ϵ� �̸��� " + userName +"�Դϴ�.";
	}
	
}
