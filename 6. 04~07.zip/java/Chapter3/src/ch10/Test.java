package ch10;

public class Test {

	public static void main(String[] args) {
		
		Car AI = new AICar();
		AI.run();
		
		System.out.println("=============");
		
		Car ML = new ManualCar();
		ML.run();
	}

}
