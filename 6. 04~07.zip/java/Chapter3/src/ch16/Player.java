package ch16;

public class Player {
	private Level level;
	
	public Player() {
		level = new Biginner();
		level.showlevelMessage();
	}
	
	public void upgradeLevel(Level level) {
		this.level = level;
		level.showlevelMessage();
	}
	
	public void play(int count) {
		level.go(count);
	}
	
}
