package ch16;

public class Biginner extends Level{

	@Override
	public void run() {
		System.out.println("õõ�� �޸��ϴ�.");
	}

	@Override
	public void jump() {
		System.out.println("���մϴ�.");
	}

	@Override
	public void turn() {
		System.out.println("���մϴ�.");
	}

	@Override
	public void showlevelMessage() {
		System.out.println("========== biginner ==========");
	}
	
	

	

	
}
