package ch06;

public class VariableTest {

	public static void main(String[] args) {
		
		
	}

}
