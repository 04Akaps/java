package ch02;

public class Student {
	
	int studentNumber;
	String studentName;
	int majorCode;
	String majorName;
	int grade;
	
}
