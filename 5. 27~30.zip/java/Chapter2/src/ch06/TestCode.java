package ch06;

public class TestCode {

	public static void main(String[] args) {
		
		Student Hojin = new Student(123456, "kim", 3);
		
		System.out.println(Hojin.showStudentInfo());
		
		
		
		
	
	}
}
