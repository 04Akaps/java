package ch16;

public class Test {

	public static void main(String[] args) {
		
		Player A = new Player();		// level  = A
		A.play(1);		
		
		Advanced B = new Advanced();
		A.upgradeLevel(B);
		A.play(2);
		
		Super C = new Super();
		A.upgradeLevel(C);
		A.play(3);
		
	}

}
