package ch02;

public class CustomerTest {

	public static void main(String[] args) {
		
		Customer customerLee = new Customer();
		customerLee.setCustomerName("�̼���");
		customerLee.setCustomerID(10010);
		
		customerLee.bonusPoint = 1000;
		System.out.println(customerLee.showCustomerInfo());
		
		VipCustomer customerA = new VipCustomer();
		customerA.setCustomerName("������");
		customerA.setCustomerID(12000);
		
		customerA.bonusPoint = 3000;
		System.out.println(customerA.showCustomerInfo());
	}
}
