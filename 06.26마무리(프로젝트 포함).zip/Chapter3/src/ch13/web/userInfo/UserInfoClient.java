package ch13.web.userInfo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import ch13.domain.userInfo.UserInfo;
import ch13.domain.userInfo.dao.UserInfoDao;
import ch13.domain.userInfo.dao.mysql.UserInfoMySqlDao;
import ch13.domain.userInfo.dao.oracle.UserInfoOracleDao;

public class UserInfoClient {

	public static void main(String[] args) throws IOException {
		
		FileInputStream fis = new FileInputStream("db.properties");
		// ���� �ȹ���
		// ������ �о��ִ� �ڵ�
		
		Properties prop = new Properties();
		prop.load(fis);
		// ���� �ȹ���
		
		String dbType = prop.getProperty("DBTYPE");
		// file�� �ִ°��� �д��ڵ�
		
		UserInfo userinfo = new UserInfo();
		userinfo.setUserId("12345");
		userinfo.setPassword("5555");
		userinfo.setUserName("hojin");
		
		UserInfoDao userinfodao = null;
		// �ʱ�ȭ �ڵ�
		
		if( dbType.equals("ORACLE")) {
			userinfodao = new UserInfoOracleDao();
		}else if(dbType.equals("MYSQL")) {
			userinfodao = new UserInfoMySqlDao();
		}else {
			System.out.println("db error");
			return;
		}
		
		userinfodao.insertUserInfo(userinfo);	
		userinfodao.updateUserInfo(userinfo);		
		userinfodao.deleteUserInfo(userinfo);		
		
		
	}

}
