package ch161;

public interface Scheduler {
	
	public abstract void getNextCall();
	public abstract void sendCallToAgent();
	
	
}
