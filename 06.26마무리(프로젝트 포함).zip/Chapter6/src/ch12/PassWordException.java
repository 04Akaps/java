package ch12;

public class PassWordException extends Exception{
	
	public PassWordException(String message) {
		super(message);
	}
}
