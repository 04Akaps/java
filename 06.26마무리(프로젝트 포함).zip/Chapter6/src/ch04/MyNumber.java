package ch04;
@FunctionalInterface
public interface MyNumber {
	int getMax(int num1, int num2);
}
