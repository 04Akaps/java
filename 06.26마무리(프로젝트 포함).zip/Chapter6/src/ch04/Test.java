package ch04;

public class Test {

	public static void main(String[] args) {
		
		MyNumber A = (x,y) ->  Math.max(x, y);
		MyNumber B = (x,y) -> x>y? x:y;
		// �� �ڵ� ��� ����
		System.out.println(B.getMax(3, 8));
		System.out.println(A.getMax(1, 5));
	}

}
