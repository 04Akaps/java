package ch03;

public interface Add {
	public int add(int x, int y);
}
