package ch09;

public class Subject {
	
	String subjectName;
	int score;
	int subjectID;
	
}
