package ch08;

public class ManTest {

	public static void main(String[] args) {
		
		Man Hojin = new Man(180, 78, "hojin", 37);
		
		System.out.println(Hojin.ShowManInfo());
	}

}
