package ch14;

public class StudentTest {

	public static void main(String[] args) {
		
		Student James = new Student("James", 5000);
		
				
		
		Bus bus100 = new Bus(100);
		
		
		James.takeBus(bus100);
		
		
		James.showInfo();
		
		
		
		
		
		
	}
	
}
