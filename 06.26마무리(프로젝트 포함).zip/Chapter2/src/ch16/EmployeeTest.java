package ch16;

public class EmployeeTest {

	public static void main(String[] args) {
		
		Employee A = new Employee();
		A.setEmployeeName("Hojin");
		
		Employee B = new Employee();
		B.setEmployeeName("Hojin2");
		
		System.out.println(A.getEmployeeName() + "," +A.getEmployeeId());
		System.out.println(B.getEmployeeName() + "," +B.getEmployeeId());
		
		
	}

}
