package ch08;

public class Plastic extends Material{

	@Override
	public void doPrinting() {
		System.out.println("���� Powder�Դϴ�.");
	}
}
