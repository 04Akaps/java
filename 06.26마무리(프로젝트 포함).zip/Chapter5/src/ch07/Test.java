package ch07;

public class Test {

	public static void main(String[] args) {
		Powder powder = new Powder();
		ThreeDPrinter3 printer = new ThreeDPrinter3();
		
		printer.setMaterial(powder);
		
		Powder P = (Powder)printer.getMaterial();
	}

}