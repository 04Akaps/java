package ch08;

public class Powder extends Material{
	
	@Override
	public void doPrinting() {
		System.out.println("���� Powder�Դϴ�.");
	}
}
