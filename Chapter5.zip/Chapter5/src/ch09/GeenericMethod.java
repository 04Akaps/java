package ch09;

public class GeenericMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
